package com.limelight.binding.input.capture;


public class NullCaptureProvider extends InputCaptureProvider {}
