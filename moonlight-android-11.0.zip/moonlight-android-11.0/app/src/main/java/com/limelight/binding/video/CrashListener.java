package com.limelight.binding.video;

public interface CrashListener {
    void notifyCrash(Exception e);
}
